package com.example.harishavara.retrofitparsing;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {
Button post;
    private APIService mAPIService;
     String response;
    TextView mResponseTv;

    String userName = "cyborg91mv@gmail.com";
    String password= "qwerty";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mResponseTv = (TextView) findViewById(R.id.tv_response);

        post=(Button)findViewById(R.id.button);
        mAPIService = ApiUtils.getAPIService();

        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Log.d("onCLick","onCLick");
                sendPost(userName, password);
                Log.d("username",userName);
                Log.d("Password",password);
            }
        });
    }
    private void sendPost(String userName, String password) {
        mAPIService.savePost(userName, password).enqueue(new Callback<Post>() {

            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                //Log.d("Message", "code..."+response.code() + " message..." + response.message()+" body..."+response.body());
                Log.d("Message", "Response code"+response.code()+ response.toString());

                if(response.isSuccessful()) {
                    showResponse(response.body().toString());
                    Log.d(String.valueOf(response), "post submitted to API." + response.body().toString());
                }
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
                Log.d(String.valueOf(response), "Unable to submit post to API.");
            }
        });
    }

    public void showResponse(String response) {
        if(mResponseTv.getVisibility() == View.GONE) {
            mResponseTv.setVisibility(View.VISIBLE);
        }
        mResponseTv.setText(response);
        Toast.makeText(MainActivity.this,response.toString(),Toast.LENGTH_SHORT).show();
    }
}
