package com.example.harishavara.retrofitparsing;

/**
 * Created by HarishaVara on 16-05-2017.
 */

public class ApiUtils {
    private ApiUtils() {}

    public static final String BASE_URL = "http://kidstiffin.com/customerLogin/";

    public static APIService getAPIService() {

        return RetrofitClient.getClient(BASE_URL).create(APIService.class);
    }
}
