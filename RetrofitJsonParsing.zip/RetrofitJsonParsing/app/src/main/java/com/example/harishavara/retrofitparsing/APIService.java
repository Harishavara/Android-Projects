package com.example.harishavara.retrofitparsing;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by HarishaVara on 16-05-2017.
 */

public interface APIService {
    @POST("/customerLogin")
    @FormUrlEncoded
    Call<Post> savePost(@Field("userName") String userName,
                        @Field("password") String password);

}
