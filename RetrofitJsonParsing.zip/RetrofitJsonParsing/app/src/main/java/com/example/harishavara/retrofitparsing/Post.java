package com.example.harishavara.retrofitparsing;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.lang.annotation.Annotation;

/**
 * Created by HarishaVara on 16-05-2017.fields
 */

public class Post{

    public Post(String userName,String password){
        this.userName=userName;
        this.password=password;
    }
   @SerializedName("userName")
    @Expose
   private String userName;
  @SerializedName("password")
    @Expose
    private String password;


    /*public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }*/
    @Override
    public String toString() {
        return "{" +
                "userName='" + userName + '\'' +
                ",password='" + password + '\'' +
                '}';
    }
}
